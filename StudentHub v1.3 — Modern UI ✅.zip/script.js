// =========================
// STUDENTHUB
// =========================

document.addEventListener("DOMContentLoaded", function () {

    // =========================
    // SAVED CLASSES
    // =========================

    let classes = JSON.parse(
        localStorage.getItem("studentClasses") || "[]"
    );


    // =========================
    // ELEMENTS
    // =========================

    let addClassButton =
        document.getElementById("addClassBtn");

    let classForm =
        document.getElementById("classForm");

    let saveClassButton =
        document.getElementById("saveClassBtn");

    let classList =
        document.getElementById("classList");


    // =========================
    // ADD CLASS
    // =========================

    addClassButton.addEventListener("click", function () {

        classForm.style.display = "block";

    });


    // =========================
    // SAVE CLASS
    // =========================

    saveClassButton.addEventListener("click", function () {

        let course =
            document.getElementById("courseName").value.trim();

        let day =
            document.getElementById("classDay").value;

        let startTime =
            document.getElementById("startTime").value;

        let endTime =
            document.getElementById("endTime").value;

        let room =
            document.getElementById("classRoom").value.trim();


        if (
            course === "" ||
            day === "" ||
            startTime === "" ||
            endTime === "" ||
            room === ""
        ) {

            alert("Please fill in all the class information.");

            return;
        }


        // Make sure end time is after start time

        if (endTime <= startTime) {

            alert("End time must be after start time.");

            return;
        }


        let classInfo = {

            course: course,
            day: day,
            startTime: startTime,
            endTime: endTime,
            room: room

        };


        classes.push(classInfo);


        // SAVE CLASSES

        localStorage.setItem(
            "studentClasses",
            JSON.stringify(classes)
        );


        displayClasses();

        displayTomorrowClasses();


        // Clear form

        document.getElementById("courseName").value = "";

        document.getElementById("classDay").value =
            "Monday";

        document.getElementById("startTime").value = "";

        document.getElementById("endTime").value = "";

        document.getElementById("classRoom").value = "";


        classForm.style.display = "none";


        alert("Class saved successfully!");

    });


    // =========================
    // DISPLAY CLASSES
    // =========================

    function displayClasses() {

        classList.innerHTML = "";


        if (classes.length === 0) {

            classList.innerHTML = `
                <p>
                    No classes added yet.
                </p>
            `;

            return;
        }


        classes.forEach(function (classInfo, index) {

            classList.innerHTML += `

                <div class="class-card">

                    <h3>${classInfo.course}</h3>

                    <p>
                        📅 ${classInfo.day}
                    </p>

                    <p>
                        ⏰ ${classInfo.startTime}
                        - 
                        ${classInfo.endTime}
                    </p>

                    <p>
                        📍 ${classInfo.room}
                    </p>

                    <button
                        onclick="deleteClass(${index})"
                    >
                        Delete
                    </button>

                </div>

            `;

        });

    }


    // =========================
    // DELETE CLASS
    // =========================

    window.deleteClass = function (index) {

        classes.splice(index, 1);


        localStorage.setItem(
            "studentClasses",
            JSON.stringify(classes)
        );


        displayClasses();

        displayTomorrowClasses();

    };


    // =========================
    // TOMORROW'S CLASSES
    // =========================

    function displayTomorrowClasses() {

        let tomorrowContainer =
            document.getElementById("tomorrowClasses");


        if (!tomorrowContainer) {
            return;
        }


        tomorrowContainer.innerHTML = "";


        let today = new Date();

        let tomorrow = new Date(today);

        tomorrow.setDate(
            today.getDate() + 1
        );


        let tomorrowDay =
            tomorrow.toLocaleDateString(
                "en-US",
                {
                    weekday: "long"
                }
            );


        let tomorrowClasses =
            classes.filter(function (classInfo) {

                return classInfo.day === tomorrowDay;

            });


        if (tomorrowClasses.length === 0) {

            tomorrowContainer.innerHTML = `
                <p>
                    🎉 No classes scheduled for tomorrow.
                </p>
            `;

            return;
        }


        tomorrowClasses.forEach(function (classInfo) {

            tomorrowContainer.innerHTML += `

                <div class="class-card">

                    <h3>
                        ${classInfo.course}
                    </h3>

                    <p>
                        ⏰ ${classInfo.startTime}
                        -
                        ${classInfo.endTime}
                    </p>

                    <p>
                        📍 ${classInfo.room}
                    </p>

                </div>

            `;

        });

    }


    // =========================
    // STUDY PLANNER
    // =========================

    let studyPlanButton =
        document.getElementById("studyPlanBtn");

    let studyResults =
        document.getElementById("studyResults");


    studyPlanButton.addEventListener(
        "click",
        function () {

            let studyPreference =
                localStorage.getItem(
                    "studyPreference"
                ) || "flexible";


            let studyDuration =
                parseInt(
                    localStorage.getItem(
                        "studyDuration"
                    ) || "60"
                );


            let studentName =
                localStorage.getItem(
                    "studentName"
                ) || "Student";


            let preferredTime = "";


            if (studyPreference === "morning") {

                preferredTime =
                    "🌅 Morning";

            }

            else if (studyPreference === "afternoon") {

                preferredTime =
                    "☀️ Afternoon";

            }

            else if (studyPreference === "evening") {

                preferredTime =
                    "🌆 Evening";

            }

            else if (studyPreference === "night") {

                preferredTime =
                    "🌙 Night";

            }

            else {

                preferredTime =
                    "🔄 Flexible";

            }


            // =========================
            // CREATE CLASS SUMMARY
            // =========================

            let classSummary = "";


            if (classes.length === 0) {

                classSummary = `
                    <p>
                        You haven't added any classes yet.
                        Add your class schedule first so
                        StudentHub can plan around it.
                    </p>
                `;

            }

            else {

                classSummary = `
                    <p>
                        You currently have
                        <strong>
                            ${classes.length}
                        </strong>
                        class(es) scheduled.
                    </p>
                `;

            }


            // =========================
            // STUDY RECOMMENDATION
            // =========================

            let recommendation = "";


            if (studyPreference === "morning") {

                recommendation = `
                    Try studying in the morning
                    before your classes become busy.
                `;

            }

            else if (studyPreference === "afternoon") {

                recommendation = `
                    Your afternoon preference means
                    you can use free periods between
                    classes for focused study.
                `;

            }

            else if (studyPreference === "evening") {

                recommendation = `
                    Your evening may be a good time
                    for focused revision after classes.
                `;

            }

            else if (studyPreference === "night") {

                recommendation = `
                    You prefer studying at night.
                    Try keeping your study sessions
                    distraction-free.
                `;

            }

            else {

                recommendation = `
                    You are flexible, so StudentHub
                    can work around your class schedule.
                `;

            }


            studyResults.innerHTML = `

                <div class="study-plan">

                    <h3>
                        💡 ${studentName}'s Study Plan
                    </h3>

                    ${classSummary}

                    <p>
                        🕐 Preferred study time:
                        <strong>
                            ${preferredTime}
                        </strong>
                    </p>

                    <p>
                        ⏱️ Preferred session:
                        <strong>
                            ${studyDuration} minutes
                        </strong>
                    </p>

                    <p>
                        ${recommendation}
                    </p>

                </div>

            `;

        }
    );


    // =========================
    // STUDENT GREETING
    // =========================

    let greeting =
        document.getElementById("greeting");


    function updateGreeting() {

        if (!greeting) {
            return;
        }


        let name =
            localStorage.getItem(
                "studentName"
            );


        if (!name) {

            greeting.textContent =
                "👋 Welcome to StudentHub!";

            return;
        }


        let hour =
            new Date().getHours();


        let message = "";


        if (hour < 12) {

            message =
                "Good morning";

        }

        else if (hour < 18) {

            message =
                "Good afternoon";

        }

        else {

            message =
                "Good evening";

        }


        greeting.textContent =
            `${message}, ${name}! 👋`;

    }


    updateGreeting();


    // =========================
    // DIGITAL CLOCK
    // =========================

    function updateClock() {

        let now = new Date();


        let hours =
            now.getHours()
                .toString()
                .padStart(2, "0");


        let minutes =
            now.getMinutes()
                .toString()
                .padStart(2, "0");


        let seconds =
            now.getSeconds()
                .toString()
                .padStart(2, "0");


        let clock =
            document.getElementById(
                "digitalClock"
            );


        if (clock) {

            clock.textContent =
                hours +
                ":" +
                minutes +
                ":" +
                seconds;

        }

    }


    updateClock();

    setInterval(
        updateClock,
        1000
    );


    // =========================
    // STUDENT PREFERENCES
    // =========================

    let savePreferencesButton =
        document.getElementById(
            "savePreferencesBtn"
        );


    savePreferencesButton.addEventListener(
        "click",
        function () {

            let studentName =
                document.getElementById(
                    "studentName"
                ).value.trim();


            let studyPreference =
                document.getElementById(
                    "studyPreference"
                ).value;


            let studyDuration =
                document.getElementById(
                    "studyDuration"
                ).value;


            if (studentName === "") {

                alert(
                    "Please enter your name."
                );

                return;
            }


            localStorage.setItem(
                "studentName",
                studentName
            );


            localStorage.setItem(
                "studyPreference",
                studyPreference
            );


            localStorage.setItem(
                "studyDuration",
                studyDuration
            );


            updateGreeting();


            alert(
                "Preferences saved successfully!"
            );
document.getElementById("preferencesPage").style.display = "none";
        }
    );


    // =========================
    // LOAD SAVED PREFERENCES
    // =========================

    let savedName =
        localStorage.getItem(
            "studentName"
        );


    let savedPreference =
        localStorage.getItem(
            "studyPreference"
        );


    let savedDuration =
        localStorage.getItem(
            "studyDuration"
        );


    if (savedName !== null) {

        document.getElementById(
            "studentName"
        ).value = savedName;

    }


    if (savedPreference !== null) {

        document.getElementById(
            "studyPreference"
        ).value = savedPreference;

    }


    if (savedDuration !== null) {

        document.getElementById(
            "studyDuration"
        ).value = savedDuration;

    }


    // =========================
    // INITIAL DISPLAY
    // =========================

    displayClasses();

    displayTomorrowClasses();


    // =========================
    // PWA INSTALL BUTTON
    // =========================

    let installButton =
    document.getElementById("installBtn");

let deferredInstallPrompt = null;


if (installButton) {

    // Hide install button by default
    installButton.style.display = "none";


    // Check if StudentHub is already installed
    if (
        window.matchMedia("(display-mode: standalone)").matches ||
        window.navigator.standalone === true
    ) {

        installButton.style.display = "block";
    } else {

        // Browser says StudentHub can be installed
        window.addEventListener(
            "beforeinstallprompt",
            function (event) {

                event.preventDefault();

                deferredInstallPrompt = event;

                installButton.style.display = "block";

            }
        );


        // User taps Install
        installButton.addEventListener(
            "click",
            async function () {

                if (!deferredInstallPrompt) {

                    alert(
                        "StudentHub cannot be installed from this preview yet. Open it from a supported HTTPS website."
                    );

                    return;
                }


                // Show browser installation prompt
                deferredInstallPrompt.prompt();


                // Wait for user's choice
                const choice =
                    await deferredInstallPrompt.userChoice;


                // Clear saved prompt
                deferredInstallPrompt = null;


                // Only hide button if installation was accepted
                if (choice.outcome === "accepted") {

                    installButton.style.display = "none";

                }

            }
        );


        // Detect when StudentHub has actually been installed
        window.addEventListener(
            "appinstalled",
            function () {

                installButton.style.display = "none";

                deferredInstallPrompt = null;

            }
        );

    }

}

// =========================
// COURSE MATERIALS
// =========================

const findMaterialsButton =
    document.getElementById("findMaterialsBtn");

const materialsResults =
    document.getElementById("materialsResults");


if (findMaterialsButton && materialsResults) {

    findMaterialsButton.addEventListener(
        "click",
        function () {

            if (classes.length === 0) {

                materialsResults.innerHTML = `
                    <div>

                        <h3>📚 Course Materials</h3>

                        <p>
                            You haven't added any courses yet.
                        </p>

                        <p>
                            Add a class first and StudentHub
                            will help you find materials for it.
                        </p>

                    </div>
                `;

                return;
            }


            let materialsHTML = `
                <div>

                    <h3>📚 Choose a Course</h3>

                    <p>
                        Select a course to find study materials.
                    </p>
            `;


            classes.forEach(function (classInfo, index) {

                materialsHTML += `

                    <button
                        class="course-material-btn"
                        onclick="showCourseMaterials(${index})"
                    >
                        📚 ${classInfo.course}
                    </button>

                `;

            });


            materialsHTML += `
                </div>
            `;


            materialsResults.innerHTML =
                materialsHTML;

        }
    );

}


// =========================
// SHOW COURSE MATERIALS
// =========================

window.showCourseMaterials = function (index) {

    let course =
        classes[index].course;


    let encodedCourse =
        encodeURIComponent(course);


    let youtubeURL =
        "https://www.youtube.com/results?search_query="
        + encodedCourse
        + "+tutorial";


    let googleURL =
    "https://www.abstechconnect.com/library";

    let pastQuestionsURL =
        "https://www.google.com/search?q="
        + encodedCourse
        + "+past+questions";


    let textbooksURL =
    "https://openstax.org/subjects";


    let chatGPTPrompt =
        encodeURIComponent(
            "I am studying "
            + course
            + ". Explain this course to me in simple terms. "
            + "Start with the key concepts I should understand "
            + "as a student, give me examples, and then quiz me "
            + "with 5 questions."
        );


    let chatGPTURL =
        "https://chatgpt.com/?q="
        + chatGPTPrompt;


    let result =
        document.getElementById(
            "materialsResults"
        );


    result.innerHTML = `

    <div>

        <h3>
            📚 ${course}
        </h3>

        <p>
            What would you like to study?
        </p>


        <button
            onclick="window.open('${youtubeURL}', '_blank')"
        >
            🎥 YouTube Videos
        </button>


        <button
            onclick="window.open('${googleURL}', '_blank')"
        >
            🔎 Lecture Notes
        </button>


        <button
            onclick="
                document.getElementById('pastQuestionSites').style.display =
                document.getElementById('pastQuestionSites').style.display === 'none'
                ? 'block'
                : 'none';
            "
        >
            📝 Past Questions
        </button>


        <div
            id="pastQuestionSites"
            style="display: none; margin-top: 10px;"
        >

            <p>
                <strong>Choose a website:</strong>
            </p>


            <button
                onclick="window.open('https://www.examguard.com.ng/', '_blank')"
            >
                📕 ExamGuard
            </button>


            <button
                onclick="window.open('https://arewaunihub.com/', '_blank')"
            >
                📗 ArewaUniHub
            </button>


            <button
                onclick="window.open('https://acadron.com.ng/', '_blank')"
            >
                📘 Acadron
            </button>

        </div>


        <button
    onclick="
        document.getElementById('textbookSites').style.display =
        document.getElementById('textbookSites').style.display === 'none'
        ? 'block'
        : 'none';
    "
>
    📖 Textbooks
</button>

<div
    id="textbookSites"
    style="display: none; margin-top: 10px;"
>

    <p>
        <strong>Choose a website:</strong>
    </p>


    <button
        onclick="window.open('https://openstax.org/subjects', '_blank')"
    >
        📚 OpenStax
    </button>


    <button
        onclick="window.open('https://open.umn.edu/opentextbooks/', '_blank')"
    >
        📖 Open Textbook Library
    </button>


    <button
        onclick="window.open('https://www.doabooks.org/', '_blank')"
    >
        🎓 DOAB
    </button>

</div>

        <button
            onclick="window.open('${chatGPTURL}', '_blank')"
        >
            🤖 Ask ChatGPT
        </button>

    </div>

`;
};
function showPastQuestionSites() {

    let sites = document.getElementById("pastQuestionSites");

    if (sites.style.display === "none") {
        sites.style.display = "block";
    } else {
        sites.style.display = "none";
    }

}

    // =========================
    // SERVICE WORKER
    // =========================

    if ("serviceWorker" in navigator) {

        navigator.serviceWorker
            .register("./service-worker.js")
            .then(function () {

                console.log(
                    "StudentHub service worker registered!"
                );

            })
            .catch(function (error) {

                console.log(
                    "Service worker registration failed:",
                    error
                );

            });

    }

// =========================
// EXPENSE TRACKER
// =========================

let expenses = JSON.parse(
    localStorage.getItem("studentExpenses") || "[]"
);

let addExpenseButton =
    document.getElementById("addExpenseBtn");

let expenseList =
    document.getElementById("expenseList");


if (addExpenseButton && expenseList) {

    addExpenseButton.addEventListener(
        "click",
        function () {

            let name =
                document.getElementById(
                    "expenseName"
                ).value.trim();

            let amount =
                document.getElementById(
                    "expenseAmount"
                ).value;

            let category =
                document.getElementById(
                    "expenseCategory"
                ).value;


            if (name === "" || amount === "") {

                alert(
                    "Please enter the expense and amount."
                );

                return;
            }


            let expense = {

                name: name,

                amount: Number(amount),

                category: category

            };


            expenses.push(expense);


            localStorage.setItem(
                "studentExpenses",
                JSON.stringify(expenses)
            );


            displayExpenses();


            document.getElementById(
                "expenseName"
            ).value = "";


            document.getElementById(
                "expenseAmount"
            ).value = "";

        }
    );

}


// =========================
// DISPLAY EXPENSES
// =========================

function displayExpenses() {

    if (!expenseList) {
        return;
    }


    expenseList.innerHTML = "";


    if (expenses.length === 0) {

        expenseList.innerHTML = `
            <p>
                No expenses added yet.
            </p>
        `;

        return;
    }
let expenseTotal =
    document.getElementById("expenseTotal");

let total = 0;

expenses.forEach(function (expense) {

    total += expense.amount;

});

if (expenseTotal) {

    expenseTotal.textContent =
        "₦" + total.toLocaleString();

}

    expenses.forEach(
        function (expense, index) {

            expenseList.innerHTML += `

                <div class="expense-card">

                    <h3>
                        ${expense.name}
                    </h3>

                    <p>
                        💰 ₦${expense.amount.toLocaleString()}
                    </p>

                    <p>
                        ${expense.category}
                    </p>

                    <button
                        onclick="deleteExpense(${index})"
                    >
                        Delete
                    </button>

                </div>

            `;

        }
    );

}


// =========================
// DELETE EXPENSE
// =========================

window.deleteExpense = function (index) {

    expenses.splice(index, 1);


    localStorage.setItem(
        "studentExpenses",
        JSON.stringify(expenses)
    );


    displayExpenses();

};


// =========================
// INITIAL EXPENSE DISPLAY
// =========================

displayExpenses();
});