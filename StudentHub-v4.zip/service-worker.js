const CACHE_NAME = "studenthub-v14";

const FILES_TO_CACHE = [
    "./",
    "./index.html",
    "./style.css",
    "./script.js",
    "./manifest.json"
];


// =========================
// INSTALL
// =========================

self.addEventListener("install", function (event) {

    event.waitUntil(

        caches.open(CACHE_NAME)
            .then(function (cache) {

                return cache.addAll(FILES_TO_CACHE);

            })

    );

    self.skipWaiting();

});


// =========================
// ACTIVATE
// =========================

self.addEventListener("activate", function (event) {

    event.waitUntil(

        caches.keys()
            .then(function (cacheNames) {

                return Promise.all(

                    cacheNames
                        .filter(function (cacheName) {

                            return cacheName !== CACHE_NAME;

                        })

                        .map(function (cacheName) {

                            return caches.delete(cacheName);

                        })

                );

            })

            .then(function () {

                return self.clients.claim();

            })

    );

});


// =========================
// FETCH
// =========================

self.addEventListener("fetch", function (event) {

    if (event.request.method !== "GET") {
        return;
    }

    event.respondWith(

        fetch(event.request)

            .then(function (response) {

                let responseClone =
                    response.clone();

                caches.open(CACHE_NAME)
                    .then(function (cache) {

                        cache.put(
                            event.request,
                            responseClone
                        );

                    });

                return response;

            })

            .catch(function () {

                return caches.match(
                    event.request
                );

            })

    );

});